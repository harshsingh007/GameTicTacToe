# Game_min_max
Tic Tac Toe using min max machine learning algorithm
